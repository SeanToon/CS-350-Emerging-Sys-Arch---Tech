/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */

#include <stdint.h>
#include <stddef.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"

// Morse code messages
const char *sos = "... --- ...";  // SOS code
const char *ok = "--- . -.-";     // OK code

volatile const char *currentMessage; // Pointer for current message
volatile bool isBlinking = false;  // Check if blinking
volatile bool messageChanged = false; // Check if button is pressed
volatile int morseIndex = 0;  // For iterating through codes
volatile int blinkPhase = 0;  // Track phase: 0=LED ON (dot/dash), 1=LED OFF (space)

// Used to control time intervals between characters and words in sequence
volatile uint32_t charSpace = 3 * 500000; // 3*500ms space between characters
volatile uint32_t wordSpace = 7 * 500000; // 7*500ms space between words

Timer_Handle timer;  // Timer handle
uint32_t dotDuration = 500000;   // Dot duration (500ms)
uint32_t dashDuration = 500000; // Dash duration (1500ms)
uint32_t timerInterval = 500000; // Timer interval(500ms)

// Functions
void processMorseCode(void);
void timerCallback(Timer_Handle myHandle, int_fast16_t status);
void gpioButtonFxn0(uint_least8_t index);
void initTimer(void);  // Initialize the timer

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback for the button press to toggle the message.
 */

void gpioButtonFxn0(uint_least8_t index)
{
    messageChanged = true;  // Change message after the current one finishes
}

/*
 *  ======== timerCallback ========
 *  Called every 500ms to process Morse code.
 */

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    processMorseCode();
}

/*
 *  ======== processMorseCode ========
 *  Process and blink Morse code with state machine logic.
 */

void processMorseCode(void)
{
    char symbol = currentMessage[morseIndex];

    // Dot or dash phase
    if (blinkPhase == 0) {
        //Red LED and time
        if (symbol == '.') {
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            Timer_setPeriod(timer, Timer_PERIOD_US, dotDuration);
        //Green LED and time
        } else if (symbol == '-') {
            GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            Timer_setPeriod(timer, Timer_PERIOD_US, dashDuration);
        }

        /*I used phases to help control timing and sequences of Morse code blinking on the LED's*/
        blinkPhase = 1;  // Move to space phase
    }

    // Space phase
    else if (blinkPhase == 1) {
        // Turn off LEDs for space after dot/dash
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

        if (symbol != ' ') {
            Timer_setPeriod(timer, Timer_PERIOD_US, charSpace);  // Space between characters
        } else {
            Timer_setPeriod(timer, Timer_PERIOD_US, wordSpace);  // Space between words
        }

        morseIndex++;  // Move to next symbol

        // End of message
        if (currentMessage[morseIndex] == '\0') {
            morseIndex = 0;  // Restart message

            // toggle the message
            if (messageChanged) {
                currentMessage = (currentMessage == sos) ? ok : sos;  // Toggle between SOS and OK
                messageChanged = false;  // Reset
            }
        }

        blinkPhase = 0;  //  back to blink phase
    }
}

/*
 *  ======== initTimer ========
 *  Initialize the timer with a callback every 500ms.
 */

void initTimer(void)
{
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = timerInterval;  // Set timer interval to 500ms
    params.periodUnits = Timer_PERIOD_US;  // Microseconds
    params.timerMode = Timer_CONTINUOUS_CALLBACK;  // Continuous callback mode
    params.timerCallback = timerCallback;  // Set callback function

    timer = Timer_open(CONFIG_TIMER_1, &params);

    if (timer == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }

    if (Timer_start(timer) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    // Initialize GPIO and Timer
    GPIO_init();
    initTimer();

    // Configure LED pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    // Configure Button pin
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    // Set initial message to SOS
    currentMessage = sos;
    isBlinking = true;

    return (NULL);
}
